#include <iostream>
#include <fstream>
#include <string>
using namespace std;
ifstream inFS;
ofstream outFS;


int menu_selec = 0;

// These integers are saved during the read through of the list, saving how many times each item appears
int appleFreq = 0;
int zucchiniFreq = 0;
int spinachFeq = 0;
int radishFreq = 0;
int potatoeFreq = 0;
int broccoliFreq = 0;
int peasFreq = 0;
int cucumbersFreq = 0;
int cranberriesFreq = 0;
int peachesFreq = 0;
int cantaloupFreq = 0;
int beetsFreq = 0;
int cauliflowerFreq = 0;
int yamsFreq = 0;
int onionsFreq = 0;
int pumpkinFreq = 0;
int celeryFreq = 0;
int limesFreq = 0;
int garlicFreq = 0;

string user_item;
string curr_item;

void Menu1() { // this function calls the int variable tied to the user_input assigned when going through the list
	cout << "Enter the Item: ";
	cin >> user_item;
	cout << " " << endl;

	if (user_item == "Potatoes") {
		cout << user_item << " " << potatoeFreq << endl;
	}

	else if (user_item == "Apples") {
		cout << user_item << " " << appleFreq << endl;
	}

	else if (user_item == "Spinach") {
		cout << user_item << " " << spinachFeq << endl;
	}

	else if (user_item == "Radishes") {
		cout << user_item << " " << radishFreq << endl;
	}

	else if (user_item == "Broccoli") {
		cout << user_item << " " << broccoliFreq << endl;
	}

	else if (user_item == "Peas") {
		cout << user_item << " " << peasFreq << endl;
	}

	else if (user_item == "Cranberries") {
		cout << user_item << " " << cranberriesFreq << endl;
	}

	else if (user_item == "Cucumbers") {
		cout << user_item << " " << cucumbersFreq << endl;
	}

	else if (user_item == "Peaches") {
		cout << user_item << " " << peachesFreq << endl;
	}

	else if (user_item == "Zucchini") {
		cout << user_item << " " << zucchiniFreq << endl;
	}
	else if (user_item == "Yams") {
		cout << user_item << " " << yamsFreq << endl;
	}
	else if (user_item == "Pumpkins") {
		cout << user_item << " " << pumpkinFreq << endl;
	}
	else if (user_item == "Celery") {
		cout << user_item << " " << celeryFreq << endl;
	}
	else if (user_item == "Limes") {
		cout << user_item << " " << limesFreq << endl;
	}
	else if (user_item == "Garlic") {
		cout << user_item << " " << garlicFreq << endl;
	}
	else if (user_item == "Onions") {
		cout << user_item << " " << onionsFreq << endl;
	}
	else if (user_item == "Cantaloupe") {
		cout << user_item << " " << cantaloupFreq << endl;
	}
	else if (user_item == "Beets") {
		cout << user_item << " " << beetsFreq << endl;
	}
	else if (user_item == "Cauliflower") {
		cout << user_item << " " << cauliflowerFreq << endl;
	}
	else {
		cout << user_item << " 0" << endl;
	}
	
	cout << " " << endl;
	menu_selec = 0;
}

void ItemChecklist() { // This function runs the List Read Through, increasing the associated variable for each menu item when it appears
	if (curr_item == "Potatoes") {
		++potatoeFreq;
	}
	
	else if (curr_item == "Apples") {
		++appleFreq;
	}

	else if (curr_item == "Spinach") {
		++spinachFeq;
	}

	else if (curr_item == "Radishes") {
		++radishFreq;
	}

	else if (curr_item == "Broccoli") {
		++broccoliFreq;
	}

	else if (curr_item == "Peas") {
		++peasFreq;
	}
	
	else if (curr_item == "Cranberries") {
		++cranberriesFreq;
	}

	else if (curr_item == "Cucumbers") {
		++cucumbersFreq;
	}

	else if (curr_item == "Peaches") {
		++peachesFreq;
	}

	else if (curr_item == "Zucchini") {
		++zucchiniFreq;
	}
	else if (curr_item == "Yams") {
		++yamsFreq;
	}
	else if (curr_item == "Pumpkins") {
		++pumpkinFreq;
	}
	else if (curr_item == "Celery") {
		++celeryFreq;
	}
	else if (curr_item == "Limes") {
		++limesFreq;
	}
	else if (curr_item == "Garlic") {
		++garlicFreq;
	}
	else if (curr_item == "Onions") {
		++onionsFreq;
	}
	else if (curr_item == "Cantaloupe") {
		++cantaloupFreq;
	}
	else if (curr_item == "Beets") {
		++beetsFreq;
	}
	else {
		++cauliflowerFreq;
	}
}

void ListReadThrough() { //This function goes through .txt document (Changed to "Grocery_List" for conveniance) and assigns variabls equal to how many times each word appears in the list
	cout << " " << endl;

	while (!inFS.eof()) { // while loop checks every word in the list and increases a variable every time the word appears
		inFS >> curr_item;
		if (!inFS.fail()) {
			ItemChecklist();
		}
	}

}

void Menu2() {

	cout << "Apples" << " " << appleFreq << endl;
	cout << "Spinach" << " " << spinachFeq << endl;
	cout << "Radishes" << " " << radishFreq << endl;
	cout << "Broccoli" << " " << broccoliFreq << endl;
	cout << "Peas" << " " << peasFreq << endl;
	cout << "Cranberries" << " " << cranberriesFreq << endl;
	cout << "Cucumbers" << " " << cucumbersFreq << endl;
	cout << "Pumpkins" << " " << pumpkinFreq << endl;
	cout << "Yams" << " " << yamsFreq << endl;
	cout << "Garlic" << " " << garlicFreq << endl;
	cout << "Cantaloupe" << " " << cantaloupFreq << endl;
	cout << "Peaches" << " " << peachesFreq << endl;
	cout << "Zucchini" << " " << zucchiniFreq << endl;
	cout << "Cauliflower" << " " << cauliflowerFreq << endl;
	cout << "Potatoes" << " " << potatoeFreq << endl;
	cout << "Beets" << " " << beetsFreq << endl;
	cout << "Onions" << " " << onionsFreq << endl;
	cout << "Celery" << " " << celeryFreq << endl;
	cout << "Limes" << " " << limesFreq << endl;

	cout << " " << endl;
	menu_selec = 0;

}

void Menu3(int grocery_count) { // Function that for loops for the sent variable to display asterisks for Menu Option 3
	int i = 0;
	for (i = 0; i < grocery_count; ++i) {
		cout << "*";

	}
	cout << "" << endl;
}

void DataFile() { // This function makes the Data file
	outFS.open("frequency.dat");

	outFS << "Apples" << " " << appleFreq << endl;
	outFS << "Spinach" << " " << spinachFeq << endl;
	outFS << "Radishes" << " " << radishFreq << endl;
	outFS << "Broccoli" << " " << broccoliFreq << endl;
	outFS << "Peas" << " " << peasFreq << endl;
	outFS << "Cranberries" << " " << cranberriesFreq << endl;
	outFS << "Cucumbers" << " " << cucumbersFreq << endl;
	outFS << "Pumpkins" << " " << pumpkinFreq << endl;
	outFS << "Yams" << " " << yamsFreq << endl;
	outFS << "Garlic" << " " << garlicFreq << endl;
	outFS << "Cantaloupe" << " " << cantaloupFreq << endl;
	outFS << "Peaches" << " " << peachesFreq << endl;
	outFS << "Zucchini" << " " << zucchiniFreq << endl;
	outFS << "Cauliflower" << " " << cauliflowerFreq << endl;
	outFS << "Potatoes" << " " << potatoeFreq << endl;
	outFS << "Beets" << " " << beetsFreq << endl;
	outFS << "Onions" << " " << onionsFreq << endl;
	outFS << "Celery" << " " << celeryFreq << endl;
	outFS << "Limes" << " " << limesFreq << endl;

	outFS.close();

}

int main() {
	
	
	inFS.open("Grocery_List.txt"); // Code that opens in the input file orginally named "CS210 Project 3 Input file", retitled it to "Grocer_List" for ease of use
	if (!inFS.is_open()) {
		cout << "Could not open file";
		return 1;
	}

	ListReadThrough();

	DataFile();
	
	while (menu_selec != 4) { // Loops the main menu display and menu user input
		cout << "-Main Menu-" << endl;
		cout << "1. Look for the frequency of a specific item" << endl;
		cout << "2. Print list with numbers that represent the frequency of all items purchased" << endl;
		cout << "3. Print histogram with frequencies in symbol form" << endl;
		cout << "4. Exit the program" << endl;

		menu_selec = 0;
		cin >> menu_selec;
		

		if (menu_selec == 1) {
			Menu1();
		}


		if (menu_selec == 2) {
			Menu2();
			
		}

		if (menu_selec == 3) {
			
			cout << "Apples ";
			Menu3(appleFreq);

			cout << "Spinach ";
			Menu3(spinachFeq);

			cout << "Radishes ";
			Menu3(radishFreq);

			cout << "Broccoli ";
			Menu3(broccoliFreq);

			cout << "Peas ";
			Menu3(peasFreq);

			cout << "Pumpkins ";
			Menu3(pumpkinFreq);

			cout << "Cranberries ";
			Menu3(cranberriesFreq);

			cout << "Cucumbers ";
			Menu3(cucumbersFreq);

			cout << "Peaches ";
			Menu3(peachesFreq);

			cout << "Yams ";
			Menu3(yamsFreq);

			cout << "Zucchini ";
			Menu3(zucchiniFreq);

			cout << "Potatoes ";
			Menu3(potatoeFreq);

			cout << "Cantaloupe ";
			Menu3(cantaloupFreq);

			cout << "Beets ";
			Menu3(beetsFreq);

			cout << "Cauliflower ";
			Menu3(cauliflowerFreq);

			cout << "Onions ";
			Menu3(onionsFreq);

			cout << "Celery ";
			Menu3(celeryFreq);

			cout << "Limes ";
			Menu3(limesFreq);

			cout << "Garlic ";
			Menu3(garlicFreq);

		}
		
	}
	
	inFS.close();

	return 0;
}

